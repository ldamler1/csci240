/******************************************************************************
CSCI 240    Assignment 6    Spring 2016
Programmer:	Lucas Damler
Section:	1
TA:			?
Date Due:	
Purpose:				
******************************************************************************/
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>

using namespace std;

int main(){
	int cnt = 0; int alph = 0; int up = 0; int lo = 0; int dig = 0;
	ifstream inputFile;
	inputFile.open("password.txt");
	
	if(inputFile.fail()){
		cout << "Failure to open";
		exit(-1);
	}
	
	char ch;
	//string gets full words/lines
	//inputFile >> ch;
	ch = inputFile.get();
	
	while(inputFile){
		while(ch != 12){
			cout << ch << endl;
			inputFile >> ch;
			if(isdigit(ch)){
				dig++;
			}
			else if(isupper(ch)){
				up++;
			}
			else if(islower(ch)){
				lo++;
			}
			cnt++;
			break;
		}
	}
	cout << "\nCount: " << cnt << endl;
	cout << "\nUpper: " << up << endl;
	cout << "\nLower: " << lo << endl;
	cout << "\nSpecial: " << alph << endl;
	cout << "\nDigit: " << dig << endl;
	inputFile.close();
	
	return 0;
}
